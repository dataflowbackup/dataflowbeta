import { Pool as NeonPool, neonConfig } from '@neondatabase/serverless';
import { drizzle as drizzleNeon } from 'drizzle-orm/neon-serverless';
import ws from "ws";
import * as schema from "@shared/schema";

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

console.log('[db] Connecting to Replit Postgres (Neon)');
neonConfig.webSocketConstructor = ws;
const pool = new NeonPool({ connectionString: process.env.DATABASE_URL });
const db = drizzleNeon({ client: pool, schema });

export { db, pool };
