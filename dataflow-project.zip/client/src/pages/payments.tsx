import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { PageHeader } from "@/components/page-header";
import { DataTable, Column } from "@/components/data-table";
import { ConfirmDialog } from "@/components/confirm-dialog";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatCurrency, formatDate, formatDateInput } from "@/lib/formatters";
import { CreditCard, Trash2, DollarSign, Plus } from "lucide-react";
import type { Payment, Supplier, Local } from "@shared/schema";

interface PaymentWithRelations extends Payment {
  supplier?: Supplier | null;
  local?: Local | null;
}

const paymentMethods = [
  { value: "efectivo", label: "Efectivo" },
  { value: "transferencia", label: "Transferencia" },
  { value: "cheque", label: "Cheque" },
  { value: "tarjeta", label: "Tarjeta" },
  { value: "otro", label: "Otro" },
];

const formSchema = z.object({
  localId: z.coerce.number().min(1, "Seleccione un local"),
  supplierId: z.coerce.number().min(1, "Seleccione un proveedor"),
  paymentNumber: z.string().optional(),
  paymentDate: z.string().min(1, "Fecha requerida"),
  paymentMethod: z.string().min(1, "Metodo de pago requerido"),
  amount: z.coerce.number().min(0.01, "Monto requerido"),
  notes: z.string().optional(),
});

type FormData = z.infer<typeof formSchema>;

export default function PaymentsPage() {
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [deletePayment, setDeletePayment] = useState<PaymentWithRelations | null>(null);

  const { data: payments = [], isLoading } = useQuery<PaymentWithRelations[]>({
    queryKey: ["/api/payments"],
  });

  const { data: suppliers = [] } = useQuery<Supplier[]>({
    queryKey: ["/api/suppliers"],
  });

  const { data: locals = [] } = useQuery<Local[]>({
    queryKey: ["/api/locals"],
  });

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      localId: 0,
      supplierId: 0,
      paymentNumber: "",
      paymentDate: formatDateInput(new Date()),
      paymentMethod: "transferencia",
      amount: 0,
      notes: "",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const res = await apiRequest("POST", "/api/payments", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/payments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      queryClient.invalidateQueries({ queryKey: ["/api/supplier-accounts"] });
      toast({ title: "Pago registrado correctamente" });
      closeDialog();
    },
    onError: (error: Error) => {
      toast({ title: "Error al registrar pago", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/payments/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/payments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      queryClient.invalidateQueries({ queryKey: ["/api/supplier-accounts"] });
      toast({ title: "Pago eliminado correctamente" });
      setDeletePayment(null);
    },
    onError: (error: Error) => {
      toast({ title: "Error al eliminar pago", description: error.message, variant: "destructive" });
    },
  });

  const openCreate = () => {
    form.reset({
      localId: 0,
      supplierId: 0,
      paymentNumber: "",
      paymentDate: formatDateInput(new Date()),
      paymentMethod: "transferencia",
      amount: 0,
      notes: "",
    });
    setIsDialogOpen(true);
  };

  const closeDialog = () => {
    setIsDialogOpen(false);
    form.reset();
  };

  const onSubmit = (data: FormData) => {
    createMutation.mutate(data);
  };

  const getMethodLabel = (method: string) => {
    return paymentMethods.find(m => m.value === method)?.label || method;
  };

  const columns: Column<PaymentWithRelations>[] = [
    {
      key: "paymentNumber",
      header: "Numero",
      cell: (row) => (
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-green-500/10">
            <CreditCard className="h-4 w-4 text-green-600" />
          </div>
          <span className="font-medium font-mono">
            {row.paymentNumber || `#${row.id}`}
          </span>
        </div>
      ),
    },
    {
      key: "supplier",
      header: "Proveedor",
      cell: (row) => row.supplier?.businessName || "-",
    },
    {
      key: "local",
      header: "Local",
      cell: (row) => row.local?.name || "-",
    },
    {
      key: "paymentDate",
      header: "Fecha",
      cell: (row) => formatDate(row.paymentDate),
    },
    {
      key: "paymentMethod",
      header: "Metodo",
      cell: (row) => (
        <Badge variant="secondary">
          {getMethodLabel(row.paymentMethod)}
        </Badge>
      ),
    },
    {
      key: "amount",
      header: "Monto",
      className: "text-right",
      cell: (row) => (
        <span className="font-mono font-medium text-green-600">
          {formatCurrency(row.amount)}
        </span>
      ),
    },
    {
      key: "actions",
      header: "",
      className: "w-20",
      cell: (row) => (
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setDeletePayment(row)}
          data-testid={`button-delete-${row.id}`}
        >
          <Trash2 className="h-4 w-4 text-destructive" />
        </Button>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Pagos"
        description="Registro de pagos a proveedores"
        actions={
          <Button onClick={openCreate} data-testid="button-new-payment">
            <Plus className="h-4 w-4 mr-2" />
            Nuevo Pago
          </Button>
        }
      />

      <DataTable
        columns={columns}
        data={payments}
        isLoading={isLoading}
        searchPlaceholder="Buscar por numero o proveedor..."
        searchKeys={["paymentNumber"]}
        emptyMessage="No hay pagos registrados"
        pageSize={15}
      />

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Nuevo Pago</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <FormField
                  control={form.control}
                  name="localId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Local *</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value?.toString() || ""}>
                        <FormControl>
                          <SelectTrigger data-testid="select-local">
                            <SelectValue placeholder="Seleccionar local" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {locals.filter(l => l.active).map((local) => (
                            <SelectItem key={local.id} value={local.id.toString()}>
                              {local.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="supplierId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Proveedor *</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value?.toString() || ""}>
                        <FormControl>
                          <SelectTrigger data-testid="select-supplier">
                            <SelectValue placeholder="Seleccionar proveedor" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {suppliers.filter(s => s.active).map((supplier) => (
                            <SelectItem key={supplier.id} value={supplier.id.toString()}>
                              {supplier.businessName}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="grid gap-4 sm:grid-cols-3">
                <FormField
                  control={form.control}
                  name="paymentNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Numero de Pago</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Opcional" data-testid="input-payment-number" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="paymentDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Fecha *</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} data-testid="input-payment-date" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="paymentMethod"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Metodo *</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-method">
                            <SelectValue placeholder="Seleccionar" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {paymentMethods.map((method) => (
                            <SelectItem key={method.value} value={method.value}>
                              {method.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="amount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Monto *</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="0.01"
                        min="0"
                        {...field}
                        className="font-mono"
                        data-testid="input-amount"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notas</FormLabel>
                    <FormControl>
                      <Textarea {...field} placeholder="Notas adicionales..." rows={2} data-testid="input-notes" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex justify-end gap-2 pt-4">
                <Button type="button" variant="outline" onClick={closeDialog} data-testid="button-cancel">
                  Cancelar
                </Button>
                <Button
                  type="submit"
                  disabled={createMutation.isPending}
                  data-testid="button-submit"
                >
                  {createMutation.isPending ? "Guardando..." : "Registrar Pago"}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={!!deletePayment}
        onOpenChange={(open) => !open && setDeletePayment(null)}
        title="Eliminar Pago"
        description="¿Esta seguro que desea eliminar este pago? Esta accion revertira los saldos de las facturas asociadas."
        confirmLabel="Eliminar"
        onConfirm={() => deletePayment && deleteMutation.mutate(deletePayment.id)}
        variant="destructive"
        isLoading={deleteMutation.isPending}
      />
    </div>
  );
}
