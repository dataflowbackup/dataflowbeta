import { useQuery } from "@tanstack/react-query";
import { useState, Fragment } from "react";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { formatCurrency } from "@/lib/formatters";
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Download,
  ChevronDown,
  ChevronRight,
} from "lucide-react";
import type { Local } from "@shared/schema";

const months = [
  "Ene", "Feb", "Mar", "Abr", "May", "Jun",
  "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"
];

const fullMonths = [
  "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
  "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
];

interface CategoryData {
  id: number;
  name: string;
  monthlyTotals: Record<number, number>;
  yearTotal: number;
}

interface GroupData {
  id: number;
  name: string;
  type: string;
  categories: CategoryData[];
  monthlyTotals: Record<number, number>;
  yearTotal: number;
}

interface SpreadsheetData {
  groups: GroupData[];
  summary: {
    income: Record<number, number>;
    expenses: Record<number, number>;
    net: Record<number, number>;
    totalIncome: number;
    totalExpenses: number;
    totalNet: number;
  };
}

export default function BalancePage() {
  const currentYear = new Date().getFullYear();
  
  const [selectedYear, setSelectedYear] = useState(currentYear.toString());
  const [selectedLocalId, setSelectedLocalId] = useState<string>("all");
  const [openGroups, setOpenGroups] = useState<Set<number>>(new Set());

  const { data: locals = [] } = useQuery<Local[]>({
    queryKey: ["/api/locals"],
  });

  const spreadsheetUrl = selectedLocalId === "all"
    ? `/api/balance-spreadsheet?year=${selectedYear}`
    : `/api/balance-spreadsheet?year=${selectedYear}&localId=${selectedLocalId}`;

  const { data: spreadsheet, isLoading } = useQuery<SpreadsheetData>({
    queryKey: [spreadsheetUrl],
  });

  const years = Array.from({ length: 5 }, (_, i) => currentYear - 2 + i);

  const toggleGroup = (groupId: number) => {
    setOpenGroups(prev => {
      const newSet = new Set(prev);
      if (newSet.has(groupId)) {
        newSet.delete(groupId);
      } else {
        newSet.add(groupId);
      }
      return newSet;
    });
  };

  const formatCell = (value: number | undefined, isNegative = false) => {
    const val = value ?? 0;
    if (val === 0) return "-";
    const formatted = formatCurrency(Math.abs(val));
    if (isNegative || val < 0) {
      return <span className="text-red-600">({formatted.replace("-", "")})</span>;
    }
    return formatted;
  };

  const renderSpreadsheetTable = () => {
    if (isLoading) {
      return (
        <div className="space-y-2">
          {[1, 2, 3, 4, 5].map(i => (
            <Skeleton key={i} className="h-10 w-full" />
          ))}
        </div>
      );
    }

    if (!spreadsheet || spreadsheet.groups.length === 0) {
      return (
        <Card>
          <CardContent className="py-8 text-center text-muted-foreground">
            No hay datos de balance para mostrar. Agregue grupos de categorias y transacciones para ver el balance.
          </CardContent>
        </Card>
      );
    }

    const { groups, summary } = spreadsheet;

    return (
      <div className="overflow-x-auto">
        <table className="w-full border-collapse text-sm" data-testid="balance-spreadsheet">
          <thead>
            <tr className="bg-muted/50">
              <th className="sticky left-0 z-10 bg-muted/50 text-left px-3 py-2 font-medium border-b min-w-[200px]">
                Categoria
              </th>
              {months.map((month, i) => (
                <th key={i} className="text-right px-2 py-2 font-medium border-b min-w-[90px]">
                  {month}
                </th>
              ))}
              <th className="text-right px-3 py-2 font-semibold border-b bg-muted min-w-[100px]">
                Total
              </th>
            </tr>
          </thead>
          <tbody>
            {groups.map((group) => {
              const isOpen = openGroups.has(group.id);
              const hasCategories = group.categories.length > 0;
              
              return (
                <Fragment key={`group-${group.id}`}>
                  <tr 
                    className={`bg-muted/30 hover-elevate ${hasCategories ? 'cursor-pointer' : ''}`}
                    onClick={() => hasCategories && toggleGroup(group.id)}
                    data-testid={`group-row-${group.id}`}
                  >
                    <td className="sticky left-0 z-10 bg-muted/30 px-3 py-2 font-semibold border-b">
                      <div className="flex items-center gap-2">
                        {hasCategories && (
                          isOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />
                        )}
                        {group.name}
                      </div>
                    </td>
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((month) => (
                      <td key={`g${group.id}-m${month}`} className="text-right px-2 py-2 font-semibold border-b font-mono">
                        {formatCell(group.monthlyTotals[month])}
                      </td>
                    ))}
                    <td className="text-right px-3 py-2 font-bold border-b bg-muted font-mono">
                      {formatCell(group.yearTotal)}
                    </td>
                  </tr>
                  {isOpen && group.categories.map((category) => (
                    <tr 
                      key={`cat-${category.id}`}
                      className="hover:bg-muted/10"
                      data-testid={`category-row-${category.id}`}
                    >
                      <td className="sticky left-0 z-10 bg-background px-3 py-1.5 pl-8 text-muted-foreground border-b">
                        {category.name}
                      </td>
                      {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((month) => (
                        <td key={`c${category.id}-m${month}`} className="text-right px-2 py-1.5 border-b font-mono text-muted-foreground">
                          {formatCell(category.monthlyTotals[month])}
                        </td>
                      ))}
                      <td className="text-right px-3 py-1.5 border-b bg-muted/50 font-mono font-medium">
                        {formatCell(category.yearTotal)}
                      </td>
                    </tr>
                  ))}
                </Fragment>
              );
            })}

            <tr className="bg-green-50 dark:bg-green-950/20">
              <td className="sticky left-0 z-10 bg-green-50 dark:bg-green-950/20 px-3 py-2 font-bold border-t-2 border-b text-green-700 dark:text-green-400">
                TOTAL INGRESOS
              </td>
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((month) => (
                <td key={month} className="text-right px-2 py-2 font-bold border-t-2 border-b font-mono text-green-700 dark:text-green-400">
                  {formatCell(summary.income[month])}
                </td>
              ))}
              <td className="text-right px-3 py-2 font-bold border-t-2 border-b bg-green-100 dark:bg-green-950/40 font-mono text-green-700 dark:text-green-400">
                {formatCell(summary.totalIncome)}
              </td>
            </tr>

            <tr className="bg-red-50 dark:bg-red-950/20">
              <td className="sticky left-0 z-10 bg-red-50 dark:bg-red-950/20 px-3 py-2 font-bold border-b text-red-700 dark:text-red-400">
                TOTAL EGRESOS
              </td>
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((month) => (
                <td key={month} className="text-right px-2 py-2 font-bold border-b font-mono text-red-700 dark:text-red-400">
                  {formatCell(summary.expenses[month])}
                </td>
              ))}
              <td className="text-right px-3 py-2 font-bold border-b bg-red-100 dark:bg-red-950/40 font-mono text-red-700 dark:text-red-400">
                {formatCell(summary.totalExpenses)}
              </td>
            </tr>

            <tr className="bg-primary/5">
              <td className="sticky left-0 z-10 bg-primary/5 px-3 py-3 font-bold border-t-2 text-lg">
                RESULTADO NETO
              </td>
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((month) => {
                const val = summary.net[month] ?? 0;
                return (
                  <td key={month} className={`text-right px-2 py-3 font-bold border-t-2 font-mono ${val >= 0 ? 'text-green-700 dark:text-green-400' : 'text-red-700 dark:text-red-400'}`}>
                    {formatCell(val)}
                  </td>
                );
              })}
              <td className={`text-right px-3 py-3 font-bold border-t-2 bg-primary/10 font-mono text-lg ${(summary.totalNet ?? 0) >= 0 ? 'text-green-700 dark:text-green-400' : 'text-red-700 dark:text-red-400'}`}>
                {formatCell(summary.totalNet)}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    );
  };

  const totalIncome = spreadsheet?.summary.totalIncome ?? 0;
  const totalExpenses = spreadsheet?.summary.totalExpenses ?? 0;
  const netResult = spreadsheet?.summary.totalNet ?? 0;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Balance P&G"
        description="Estado de resultados y balances mensuales"
        actions={
          <Button variant="outline" data-testid="button-export">
            <Download className="h-4 w-4 mr-2" />
            Exportar
          </Button>
        }
      />

      <div className="flex flex-col sm:flex-row gap-4">
        <Select value={selectedYear} onValueChange={setSelectedYear}>
          <SelectTrigger className="w-32" data-testid="select-year">
            <SelectValue placeholder="Ano" />
          </SelectTrigger>
          <SelectContent>
            {years.map((year) => (
              <SelectItem key={year} value={year.toString()}>
                {year}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={selectedLocalId} onValueChange={setSelectedLocalId}>
          <SelectTrigger className="w-48" data-testid="select-local">
            <SelectValue placeholder="Local" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos los locales</SelectItem>
            {locals.map((local) => (
              <SelectItem key={local.id} value={local.id.toString()}>
                {local.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Ingresos Anuales</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono text-green-600" data-testid="stat-income">
              {isLoading ? <Skeleton className="h-8 w-32" /> : formatCurrency(totalIncome)}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Egresos Anuales</CardTitle>
            <TrendingDown className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono text-red-600" data-testid="stat-expenses">
              {isLoading ? <Skeleton className="h-8 w-32" /> : formatCurrency(totalExpenses)}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Resultado Neto</CardTitle>
            <DollarSign className={`h-4 w-4 ${netResult >= 0 ? "text-green-600" : "text-red-600"}`} />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold font-mono ${netResult >= 0 ? "text-green-600" : "text-red-600"}`} data-testid="stat-result">
              {isLoading ? <Skeleton className="h-8 w-32" /> : formatCurrency(netResult)}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle>Detalle por Categoria</CardTitle>
        </CardHeader>
        <CardContent className="p-0 md:p-6">
          {renderSpreadsheetTable()}
        </CardContent>
      </Card>
    </div>
  );
}
