import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { PageHeader } from "@/components/page-header";
import { DataTable, Column } from "@/components/data-table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatCurrency, formatCuit } from "@/lib/formatters";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";
import { 
  Building2, 
  Eye,
  AlertCircle,
  CheckCircle,
  DollarSign,
  TrendingDown,
  PieChart as PieChartIcon,
} from "lucide-react";
import type { Supplier } from "@shared/schema";

interface SupplierAccount extends Supplier {
  totalDebt: number;
  invoiceCount: number;
  overdueCount: number;
}

const CHART_COLORS = [
  "#ef4444", "#f97316", "#f59e0b", "#eab308", "#84cc16",
  "#22c55e", "#14b8a6", "#06b6d4", "#0ea5e9", "#3b82f6",
  "#6366f1", "#8b5cf6", "#a855f7", "#d946ef", "#ec4899",
];

export default function AccountsPage() {
  const { data: accounts = [], isLoading } = useQuery<SupplierAccount[]>({
    queryKey: ["/api/supplier-accounts"],
  });

  const totalDebt = accounts.reduce((sum, acc) => sum + (acc.totalDebt || 0), 0);
  const suppliersWithDebt = accounts.filter(a => a.totalDebt > 0).length;
  const overdueTotal = accounts.reduce((sum, acc) => sum + (acc.overdueCount || 0), 0);

  const pieChartData = useMemo(() => {
    return accounts
      .filter(a => a.totalDebt > 0)
      .sort((a, b) => b.totalDebt - a.totalDebt)
      .slice(0, 10)
      .map((account) => ({
        name: account.businessName,
        value: account.totalDebt,
      }));
  }, [accounts]);

  const columns: Column<SupplierAccount>[] = [
    {
      key: "businessName",
      header: "Proveedor",
      cell: (row) => (
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
            <Building2 className="h-4 w-4 text-primary" />
          </div>
          <div>
            <div className="font-medium">{row.businessName}</div>
            <div className="text-xs text-muted-foreground font-mono">
              {formatCuit(row.cuit)}
            </div>
          </div>
        </div>
      ),
    },
    {
      key: "invoiceCount",
      header: "Facturas",
      cell: (row) => (
        <Badge variant="secondary">
          {row.invoiceCount || 0}
        </Badge>
      ),
    },
    {
      key: "totalDebt",
      header: "Deuda Total",
      className: "text-right",
      cell: (row) => (
        <span className={`font-mono font-medium ${row.totalDebt > 0 ? "text-destructive" : "text-green-600"}`}>
          {formatCurrency(row.totalDebt)}
        </span>
      ),
    },
    {
      key: "overdueCount",
      header: "Vencidas",
      cell: (row) => (
        row.overdueCount > 0 ? (
          <Badge variant="destructive" className="gap-1">
            <AlertCircle className="h-3 w-3" />
            {row.overdueCount}
          </Badge>
        ) : (
          <Badge variant="outline" className="gap-1 text-green-600">
            <CheckCircle className="h-3 w-3" />
            0
          </Badge>
        )
      ),
    },
    {
      key: "paymentDays",
      header: "Plazo",
      cell: (row) => (
        <span className="text-sm">
          {row.paymentDays || 0} dias
        </span>
      ),
    },
    {
      key: "actions",
      header: "",
      className: "w-20",
      cell: (row) => (
        <Link href={`/cuentas-corrientes/${row.id}`}>
          <Button variant="ghost" size="icon" data-testid={`button-view-${row.id}`}>
            <Eye className="h-4 w-4" />
          </Button>
        </Link>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Cuentas Corrientes"
        description="Estado de cuenta con cada proveedor"
      />

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Deuda Total</CardTitle>
            <DollarSign className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono text-destructive" data-testid="stat-total-debt">
              {formatCurrency(totalDebt)}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Proveedores con Deuda</CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono" data-testid="stat-suppliers-debt">
              {suppliersWithDebt}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Facturas Vencidas</CardTitle>
            <AlertCircle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono text-destructive" data-testid="stat-overdue">
              {overdueTotal}
            </div>
          </CardContent>
        </Card>
      </div>

      {pieChartData.length > 0 && (
        <Card data-testid="card-debt-chart">
          <CardHeader className="flex flex-row items-center justify-between gap-2">
            <CardTitle className="text-base">Distribucion de Deuda por Proveedor</CardTitle>
            <PieChartIcon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieChartData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  >
                    {pieChartData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value: number) => [formatCurrency(value), "Deuda"]}
                  />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      )}

      <DataTable
        columns={columns}
        data={accounts}
        isLoading={isLoading}
        searchPlaceholder="Buscar por proveedor..."
        searchKeys={["businessName"]}
        emptyMessage="No hay cuentas corrientes. Las cuentas se generan automaticamente al cargar facturas."
        pageSize={15}
      />
    </div>
  );
}
