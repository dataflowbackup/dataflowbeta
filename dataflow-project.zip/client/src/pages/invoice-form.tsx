import { useState, useEffect, useMemo } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLocation, useParams } from "wouter";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatCurrency, formatDateInput } from "@/lib/formatters";
import { Plus, Trash2, Calculator, AlertTriangle, TrendingUp, TrendingDown } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import type { Supplier, Local, Supply, Tax, Rubro } from "@shared/schema";

const invoiceTypes = [
  { value: "A", label: "Factura A" },
  { value: "B", label: "Factura B" },
  { value: "C", label: "Factura C" },
  { value: "E", label: "Factura E" },
  { value: "M", label: "Factura M" },
  { value: "NC-A", label: "Nota de Credito A" },
  { value: "NC-B", label: "Nota de Credito B" },
  { value: "NC-C", label: "Nota de Credito C" },
  { value: "ND-A", label: "Nota de Debito A" },
  { value: "ND-B", label: "Nota de Debito B" },
  { value: "ND-C", label: "Nota de Debito C" },
  { value: "REM", label: "Remito" },
];

const ivaConditions = [
  { value: "responsable_inscripto", label: "Responsable Inscripto" },
  { value: "monotributista", label: "Monotributista" },
  { value: "exento", label: "Exento" },
  { value: "consumidor_final", label: "Consumidor Final" },
];

const expenseTypes = [
  { value: "cmv", label: "CMV (Costo de Mercaderia)" },
  { value: "admin", label: "Administracion / Gastos" },
];

const itemSchema = z.object({
  supplyId: z.coerce.number().optional(),
  description: z.string().optional(),
  quantity: z.coerce.number().min(0.0001, "Cantidad requerida"),
  unitPrice: z.coerce.number().min(0, "Precio requerido"),
  subtotal: z.coerce.number(),
  rubroId: z.coerce.number().optional(),
});

const taxItemSchema = z.object({
  taxId: z.coerce.number(),
  baseAmount: z.coerce.number(),
  taxAmount: z.coerce.number(),
});

const formSchema = z.object({
  localId: z.coerce.number().min(1, "Seleccione un local"),
  supplierId: z.coerce.number().min(1, "Seleccione un proveedor"),
  invoiceNumber: z.string().min(1, "Numero de factura requerido"),
  invoiceType: z.string().min(1, "Tipo de comprobante requerido"),
  invoiceDate: z.string().min(1, "Fecha requerida"),
  dueDate: z.string().optional(),
  paymentDays: z.coerce.number().min(0).default(0),
  ivaCondition: z.string().optional(),
  expenseType: z.string().default("cmv"),
  discount: z.coerce.number().min(0).default(0),
  advancePayment: z.coerce.number().min(0).default(0),
  notes: z.string().optional(),
  items: z.array(itemSchema).min(1, "Debe agregar al menos un item"),
  taxes: z.array(taxItemSchema).default([]),
});

type FormData = z.infer<typeof formSchema>;

export default function InvoiceFormPage() {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const params = useParams<{ id: string }>();
  const isEditing = params.id && params.id !== "nueva";

  const { data: suppliers = [] } = useQuery<Supplier[]>({
    queryKey: ["/api/suppliers"],
  });

  const { data: locals = [] } = useQuery<Local[]>({
    queryKey: ["/api/locals"],
  });

  const { data: supplies = [] } = useQuery<Supply[]>({
    queryKey: ["/api/supplies"],
  });

  const { data: taxes = [] } = useQuery<Tax[]>({
    queryKey: ["/api/taxes"],
  });

  const { data: rubros = [] } = useQuery<Rubro[]>({
    queryKey: ["/api/rubros"],
  });

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      localId: 0,
      supplierId: 0,
      invoiceNumber: "",
      invoiceType: "A",
      invoiceDate: formatDateInput(new Date()),
      dueDate: "",
      paymentDays: 0,
      ivaCondition: "responsable_inscripto",
      expenseType: "cmv",
      discount: 0,
      advancePayment: 0,
      notes: "",
      items: [{ supplyId: undefined, description: "", quantity: 1, unitPrice: 0, subtotal: 0, rubroId: undefined }],
      taxes: [],
    },
  });

  const { fields: itemFields, append: appendItem, remove: removeItem } = useFieldArray({
    control: form.control,
    name: "items",
  });

  const { fields: taxFields, append: appendTax, remove: removeTax, replace: replaceTaxes } = useFieldArray({
    control: form.control,
    name: "taxes",
  });

  const watchItems = form.watch("items");
  const watchDiscount = form.watch("discount");
  const watchAdvancePayment = form.watch("advancePayment");
  const watchSupplierId = form.watch("supplierId");
  const watchInvoiceDate = form.watch("invoiceDate");
  const watchPaymentDays = form.watch("paymentDays");

  useEffect(() => {
    const supplier = suppliers.find(s => s.id === watchSupplierId);
    if (supplier) {
      if (supplier.paymentDays) {
        form.setValue("paymentDays", supplier.paymentDays);
      }
      if (supplier.ivaCondition) {
        form.setValue("ivaCondition", supplier.ivaCondition);
      }
    }
  }, [watchSupplierId, suppliers, form]);

  useEffect(() => {
    if (watchInvoiceDate && watchPaymentDays >= 0) {
      const invoiceDate = new Date(watchInvoiceDate);
      invoiceDate.setDate(invoiceDate.getDate() + watchPaymentDays);
      form.setValue("dueDate", formatDateInput(invoiceDate));
    }
  }, [watchInvoiceDate, watchPaymentDays, form]);

  const calculations = useMemo(() => {
    const subtotal = watchItems.reduce((sum, item) => {
      const qty = item.quantity || 0;
      const price = item.unitPrice || 0;
      return sum + (qty * price);
    }, 0);

    const discount = watchDiscount || 0;
    const subtotalAfterDiscount = subtotal - discount;

    const taxTotal = taxFields.reduce((sum, _, index) => {
      const taxAmount = form.getValues(`taxes.${index}.taxAmount`) || 0;
      return sum + taxAmount;
    }, 0);

    const total = subtotalAfterDiscount + taxTotal;
    const advancePayment = watchAdvancePayment || 0;
    const balance = total - advancePayment;

    return { subtotal, discount, subtotalAfterDiscount, taxTotal, total, balance };
  }, [watchItems, watchDiscount, watchAdvancePayment, taxFields, form]);

  useEffect(() => {
    watchItems.forEach((item, index) => {
      const subtotal = (item.quantity || 0) * (item.unitPrice || 0);
      form.setValue(`items.${index}.subtotal`, subtotal);
    });
  }, [watchItems, form]);

  const handleSupplyChange = (index: number, supplyId: number) => {
    const supply = supplies.find(s => s.id === supplyId);
    if (supply) {
      form.setValue(`items.${index}.supplyId`, supplyId);
      form.setValue(`items.${index}.description`, supply.name);
      if (supply.rubroId) {
        form.setValue(`items.${index}.rubroId`, supply.rubroId);
      }
    }
  };

  const COST_VARIATION_THRESHOLD = 15;

  const costVariations = useMemo(() => {
    return watchItems.map((item) => {
      if (!item.supplyId || !item.unitPrice) return null;
      
      const supply = supplies.find(s => s.id === item.supplyId);
      if (!supply || !supply.lastCost || parseFloat(String(supply.lastCost)) === 0) return null;
      
      const previousCost = parseFloat(String(supply.lastCost));
      const newCost = item.unitPrice;
      const variation = ((newCost - previousCost) / previousCost) * 100;
      
      if (Math.abs(variation) >= COST_VARIATION_THRESHOLD) {
        return {
          supplyName: supply.name,
          previousCost,
          newCost,
          variation: variation.toFixed(1),
          isIncrease: variation > 0,
        };
      }
      return null;
    }).filter(Boolean);
  }, [watchItems, supplies]);

  const costComparison = useMemo(() => {
    return watchItems.map((item, index) => {
      if (!item.supplyId) return null;
      
      const supply = supplies.find(s => s.id === item.supplyId);
      if (!supply) return null;
      
      const previousCost = parseFloat(String(supply.lastCost)) || 0;
      const currentCPP = parseFloat(String(supply.unitCost)) || 0;
      const newCost = item.unitPrice || 0;
      const quantity = item.quantity || 0;
      
      let variation = 0;
      if (previousCost > 0 && newCost > 0) {
        variation = ((newCost - previousCost) / previousCost) * 100;
      }
      
      return {
        index,
        supplyName: supply.name,
        previousCost,
        currentCPP,
        newCost,
        quantity,
        newTotal: newCost * quantity,
        variation: variation.toFixed(1),
        hasVariation: Math.abs(variation) >= 5,
        isIncrease: variation > 0,
      };
    }).filter(Boolean);
  }, [watchItems, supplies]);

  const handleAddTax = (taxId: number) => {
    const tax = taxes.find(t => t.id === taxId);
    if (!tax) return;

    const existing = taxFields.find((_, i) => form.getValues(`taxes.${i}.taxId`) === taxId);
    if (existing) {
      toast({ title: "Este impuesto ya fue agregado", variant: "destructive" });
      return;
    }

    const baseAmount = calculations.subtotalAfterDiscount;
    const percentage = parseFloat(tax.percentage);
    const taxAmount = (baseAmount * percentage) / 100;

    appendTax({ taxId, baseAmount, taxAmount });
  };

  const recalculateTaxes = () => {
    const newTaxes = taxFields.map((_, index) => {
      const taxId = form.getValues(`taxes.${index}.taxId`);
      const tax = taxes.find(t => t.id === taxId);
      if (!tax) return form.getValues(`taxes.${index}`);

      const baseAmount = calculations.subtotalAfterDiscount;
      const percentage = parseFloat(tax.percentage);
      const taxAmount = (baseAmount * percentage) / 100;

      return { taxId, baseAmount, taxAmount };
    });
    replaceTaxes(newTaxes);
  };

  const createMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const payload = {
        ...data,
        subtotal: calculations.subtotal,
        taxTotal: calculations.taxTotal,
        total: calculations.total,
        balance: calculations.balance,
      };
      const res = await apiRequest("POST", "/api/invoices", payload);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      queryClient.invalidateQueries({ queryKey: ["/api/supplies"] });
      toast({ title: "Factura creada correctamente" });
      navigate("/facturas");
    },
    onError: (error: Error) => {
      toast({ title: "Error al crear factura", description: error.message, variant: "destructive" });
    },
  });

  const onSubmit = (data: FormData) => {
    createMutation.mutate(data);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title={isEditing ? "Editar Factura" : "Nueva Factura"}
        description="Complete los datos del comprobante"
        backHref="/facturas"
      />

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-3">
            <div className="lg:col-span-2 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Datos del Comprobante</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <FormField
                      control={form.control}
                      name="localId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Local *</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value?.toString() || ""}>
                            <FormControl>
                              <SelectTrigger data-testid="select-local">
                                <SelectValue placeholder="Seleccionar local" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {locals.filter(l => l.active).map((local) => (
                                <SelectItem key={local.id} value={local.id.toString()}>
                                  {local.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="supplierId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Proveedor *</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value?.toString() || ""}>
                            <FormControl>
                              <SelectTrigger data-testid="select-supplier">
                                <SelectValue placeholder="Seleccionar proveedor" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {suppliers.filter(s => s.active).map((supplier) => (
                                <SelectItem key={supplier.id} value={supplier.id.toString()}>
                                  {supplier.businessName}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid gap-4 sm:grid-cols-3">
                    <FormField
                      control={form.control}
                      name="invoiceType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Tipo de Comprobante *</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-invoice-type">
                                <SelectValue placeholder="Seleccionar tipo" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {invoiceTypes.map((type) => (
                                <SelectItem key={type.value} value={type.value}>
                                  {type.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="invoiceNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Numero de Comprobante *</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="0001-00000001" data-testid="input-invoice-number" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="invoiceDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Fecha *</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} data-testid="input-invoice-date" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid gap-4 sm:grid-cols-3">
                    <FormField
                      control={form.control}
                      name="ivaCondition"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Condicion IVA</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value || ""}>
                            <FormControl>
                              <SelectTrigger data-testid="select-iva-condition">
                                <SelectValue placeholder="Seleccionar" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {ivaConditions.map((condition) => (
                                <SelectItem key={condition.value} value={condition.value}>
                                  {condition.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="expenseType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Tipo de Gasto *</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-expense-type">
                                <SelectValue placeholder="Seleccionar tipo" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {expenseTypes.map((type) => (
                                <SelectItem key={type.value} value={type.value}>
                                  {type.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="paymentDays"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Dias de Plazo</FormLabel>
                          <FormControl>
                            <Input type="number" min={0} {...field} data-testid="input-payment-days" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid gap-4 sm:grid-cols-2">
                    <FormField
                      control={form.control}
                      name="dueDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Fecha de Vencimiento</FormLabel>
                          <FormControl>
                            <Input 
                              type="date" 
                              {...field} 
                              className="bg-muted" 
                              data-testid="input-due-date" 
                            />
                          </FormControl>
                          <p className="text-xs text-muted-foreground">
                            Calculado automaticamente segun dias de plazo
                          </p>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between gap-2">
                  <CardTitle>Items / Insumos</CardTitle>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => appendItem({ supplyId: undefined, description: "", quantity: 1, unitPrice: 0, subtotal: 0, rubroId: undefined })}
                    data-testid="button-add-item"
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Agregar Item
                  </Button>
                </CardHeader>
                <CardContent className="space-y-4">
                  {itemFields.map((field, index) => (
                    <div key={field.id} className="grid gap-3 p-4 rounded-lg border bg-muted/30">
                      <div className="grid gap-3 sm:grid-cols-2">
                        <FormField
                          control={form.control}
                          name={`items.${index}.supplyId`}
                          render={({ field: itemField }) => (
                            <FormItem>
                              <FormLabel>Insumo</FormLabel>
                              <Select
                                onValueChange={(val) => handleSupplyChange(index, parseInt(val))}
                                value={itemField.value?.toString() || ""}
                              >
                                <FormControl>
                                  <SelectTrigger data-testid={`select-supply-${index}`}>
                                    <SelectValue placeholder="Seleccionar insumo" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {supplies.filter(s => s.active).map((supply) => (
                                    <SelectItem key={supply.id} value={supply.id.toString()}>
                                      {supply.name}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name={`items.${index}.description`}
                          render={({ field: itemField }) => (
                            <FormItem>
                              <FormLabel>Descripcion</FormLabel>
                              <FormControl>
                                <Input {...itemField} placeholder="Descripcion del item" data-testid={`input-description-${index}`} />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                      </div>
                      <div className="grid gap-3 sm:grid-cols-4">
                        <FormField
                          control={form.control}
                          name={`items.${index}.quantity`}
                          render={({ field: itemField }) => (
                            <FormItem>
                              <FormLabel>Cantidad</FormLabel>
                              <FormControl>
                                <Input
                                  type="number"
                                  step="0.0001"
                                  min="0"
                                  {...itemField}
                                  className="font-mono"
                                  data-testid={`input-quantity-${index}`}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name={`items.${index}.unitPrice`}
                          render={({ field: itemField }) => (
                            <FormItem>
                              <FormLabel>Precio Unitario</FormLabel>
                              <FormControl>
                                <Input
                                  type="number"
                                  step="0.01"
                                  min="0"
                                  {...itemField}
                                  className="font-mono"
                                  data-testid={`input-unit-price-${index}`}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name={`items.${index}.rubroId`}
                          render={({ field: itemField }) => (
                            <FormItem>
                              <FormLabel>Rubro</FormLabel>
                              <Select
                                onValueChange={(val) => itemField.onChange(parseInt(val))}
                                value={itemField.value?.toString() || ""}
                              >
                                <FormControl>
                                  <SelectTrigger data-testid={`select-rubro-${index}`}>
                                    <SelectValue placeholder="Seleccionar" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {rubros.filter(r => r.active).map((rubro) => (
                                    <SelectItem key={rubro.id} value={rubro.id.toString()}>
                                      {rubro.name}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </FormItem>
                          )}
                        />
                        <div className="flex items-end gap-2">
                          <div className="flex-1">
                            <FormLabel>Subtotal</FormLabel>
                            <div className="h-10 px-3 py-2 rounded-md border bg-muted font-mono text-sm flex items-center">
                              {formatCurrency(watchItems[index]?.quantity * watchItems[index]?.unitPrice || 0)}
                            </div>
                          </div>
                          {itemFields.length > 1 && (
                            <Button
                              type="button"
                              variant="ghost"
                              size="icon"
                              onClick={() => removeItem(index)}
                              data-testid={`button-remove-item-${index}`}
                            >
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {costVariations.length > 0 && (
                <Alert variant="destructive" className="border-orange-500 bg-orange-50 dark:bg-orange-950/20" data-testid="alert-cost-variation">
                  <AlertTriangle className="h-4 w-4 text-orange-600" />
                  <AlertDescription>
                    <div className="font-medium text-orange-800 dark:text-orange-200 mb-2">
                      Alerta de Variacion de Costos (umbral: {COST_VARIATION_THRESHOLD}%)
                    </div>
                    <div className="space-y-1">
                      {costVariations.map((v: any, idx) => (
                        <div key={idx} className="flex items-center gap-2 text-sm">
                          {v.isIncrease ? (
                            <TrendingUp className="h-4 w-4 text-red-600" />
                          ) : (
                            <TrendingDown className="h-4 w-4 text-green-600" />
                          )}
                          <span className="text-foreground">
                            <strong>{v.supplyName}</strong>: {formatCurrency(v.previousCost)} → {formatCurrency(v.newCost)} 
                            <span className={v.isIncrease ? "text-red-600 ml-1" : "text-green-600 ml-1"}>
                              ({v.isIncrease ? "+" : ""}{v.variation}%)
                            </span>
                          </span>
                        </div>
                      ))}
                    </div>
                  </AlertDescription>
                </Alert>
              )}

              {costComparison.length > 0 && (
                <Card data-testid="card-cost-comparison">
                  <CardHeader>
                    <CardTitle className="text-base">Comparativa de Costos</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Insumo</TableHead>
                          <TableHead className="text-right">CPP Actual</TableHead>
                          <TableHead className="text-right">Costo Anterior</TableHead>
                          <TableHead className="text-right">Costo Nuevo</TableHead>
                          <TableHead className="text-right">Variacion</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {costComparison.map((item: any) => (
                          <TableRow key={item.index} data-testid={`row-cost-comparison-${item.index}`}>
                            <TableCell className="font-medium">{item.supplyName}</TableCell>
                            <TableCell className="text-right font-mono">
                              {item.currentCPP > 0 ? formatCurrency(item.currentCPP) : "-"}
                            </TableCell>
                            <TableCell className="text-right font-mono">
                              {item.previousCost > 0 ? formatCurrency(item.previousCost) : "-"}
                            </TableCell>
                            <TableCell className="text-right font-mono">
                              {formatCurrency(item.newCost)}
                            </TableCell>
                            <TableCell className="text-right font-mono">
                              {item.previousCost > 0 ? (
                                <span className={
                                  item.hasVariation 
                                    ? (item.isIncrease ? "text-red-600" : "text-green-600")
                                    : ""
                                }>
                                  {item.isIncrease ? "+" : ""}{item.variation}%
                                </span>
                              ) : (
                                <span className="text-muted-foreground">Primera compra</span>
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              )}

              <Card>
                <CardHeader className="flex flex-row items-center justify-between gap-2">
                  <CardTitle>Impuestos</CardTitle>
                  <div className="flex items-center gap-2">
                    <Select onValueChange={(val) => handleAddTax(parseInt(val))}>
                      <SelectTrigger className="w-48" data-testid="select-add-tax">
                        <SelectValue placeholder="Agregar impuesto" />
                      </SelectTrigger>
                      <SelectContent>
                        {taxes.filter(t => t.active).map((tax) => (
                          <SelectItem key={tax.id} value={tax.id.toString()}>
                            {tax.name} ({tax.percentage}%)
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      onClick={recalculateTaxes}
                      title="Recalcular impuestos"
                      data-testid="button-recalculate-taxes"
                    >
                      <Calculator className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {taxFields.length === 0 ? (
                    <p className="text-sm text-muted-foreground text-center py-4">
                      No hay impuestos agregados. Seleccione uno del menu superior.
                    </p>
                  ) : (
                    <div className="space-y-3">
                      {taxFields.map((field, index) => {
                        const tax = taxes.find(t => t.id === form.getValues(`taxes.${index}.taxId`));
                        return (
                          <div key={field.id} className="flex items-center justify-between p-3 rounded-lg border">
                            <div>
                              <div className="font-medium">{tax?.name || "Impuesto"}</div>
                              <div className="text-sm text-muted-foreground">
                                {tax?.percentage}% sobre {formatCurrency(form.getValues(`taxes.${index}.baseAmount`))}
                              </div>
                            </div>
                            <div className="flex items-center gap-3">
                              <span className="font-mono font-medium">
                                {formatCurrency(form.getValues(`taxes.${index}.taxAmount`))}
                              </span>
                              <Button
                                type="button"
                                variant="ghost"
                                size="icon"
                                onClick={() => removeTax(index)}
                                data-testid={`button-remove-tax-${index}`}
                              >
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </Button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Notas</CardTitle>
                </CardHeader>
                <CardContent>
                  <FormField
                    control={form.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Textarea {...field} placeholder="Observaciones o notas adicionales..." rows={3} data-testid="input-notes" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>
            </div>

            <div>
              <Card className="sticky top-6">
                <CardHeader>
                  <CardTitle>Resumen</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Subtotal</span>
                      <span className="font-mono">{formatCurrency(calculations.subtotal)}</span>
                    </div>
                    <FormField
                      control={form.control}
                      name="discount"
                      render={({ field }) => (
                        <div className="flex justify-between items-center text-sm">
                          <span className="text-muted-foreground">Descuento</span>
                          <Input
                            type="number"
                            step="0.01"
                            min="0"
                            {...field}
                            className="w-28 h-8 font-mono text-right"
                            data-testid="input-discount"
                          />
                        </div>
                      )}
                    />
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Subtotal c/Desc.</span>
                      <span className="font-mono">{formatCurrency(calculations.subtotalAfterDiscount)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Impuestos</span>
                      <span className="font-mono">{formatCurrency(calculations.taxTotal)}</span>
                    </div>
                  </div>

                  <Separator />

                  <div className="flex justify-between font-medium">
                    <span>Total</span>
                    <span className="font-mono text-lg">{formatCurrency(calculations.total)}</span>
                  </div>

                  <FormField
                    control={form.control}
                    name="advancePayment"
                    render={({ field }) => (
                      <div className="flex justify-between items-center text-sm">
                        <span className="text-muted-foreground">Pago Anticipado</span>
                        <Input
                          type="number"
                          step="0.01"
                          min="0"
                          {...field}
                          className="w-28 h-8 font-mono text-right"
                          data-testid="input-advance-payment"
                        />
                      </div>
                    )}
                  />

                  <Separator />

                  <div className="flex justify-between font-medium text-primary">
                    <span>Saldo a Pagar</span>
                    <span className="font-mono text-lg">{formatCurrency(calculations.balance)}</span>
                  </div>

                  <div className="pt-4 space-y-2">
                    <Button
                      type="submit"
                      className="w-full"
                      disabled={createMutation.isPending}
                      data-testid="button-submit"
                    >
                      {createMutation.isPending ? "Guardando..." : "Guardar Factura"}
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      className="w-full"
                      onClick={() => navigate("/facturas")}
                      data-testid="button-cancel"
                    >
                      Cancelar
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </form>
      </Form>
    </div>
  );
}
