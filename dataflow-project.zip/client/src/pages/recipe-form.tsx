import { useState, useEffect, useMemo } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLocation, useParams } from "wouter";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatCurrency, formatPercentage, formatNumber } from "@/lib/formatters";
import { Plus, Trash2, TrendingUp, DollarSign, Percent, Package } from "lucide-react";
import type { RecipeCategory, Supply, UnitOfMeasure } from "@shared/schema";

interface SupplyWithUnit extends Supply {
  unitOfMeasure?: UnitOfMeasure | null;
}

const ingredientSchema = z.object({
  supplyId: z.coerce.number().min(1, "Seleccione un insumo"),
  quantityWithWaste: z.coerce.number().min(0.0001, "Cantidad requerida"),
  wastePercentage: z.coerce.number().min(0).max(100).default(0),
});

const formSchema = z.object({
  name: z.string().min(1, "El nombre es requerido"),
  categoryId: z.coerce.number().optional(),
  description: z.string().optional(),
  salePrice: z.coerce.number().min(0).default(0),
  usefulYield: z.coerce.number().optional(),
  ingredients: z.array(ingredientSchema).min(1, "Debe agregar al menos un ingrediente"),
});

type FormData = z.infer<typeof formSchema>;

export default function RecipeFormPage() {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const params = useParams<{ id: string }>();
  const isEditing = params.id && params.id !== "nueva";

  const { data: categories = [] } = useQuery<RecipeCategory[]>({
    queryKey: ["/api/recipe-categories"],
  });

  const { data: supplies = [] } = useQuery<SupplyWithUnit[]>({
    queryKey: ["/api/supplies"],
  });

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      categoryId: undefined,
      description: "",
      salePrice: 0,
      usefulYield: undefined,
      ingredients: [{ supplyId: 0, quantityWithWaste: 1, wastePercentage: 0 }],
    },
  });

  const { fields: ingredientFields, append: appendIngredient, remove: removeIngredient } = useFieldArray({
    control: form.control,
    name: "ingredients",
  });

  const watchIngredients = form.watch("ingredients");
  const watchSalePrice = form.watch("salePrice");

  const calculations = useMemo(() => {
    let totalCost = 0;

    watchIngredients.forEach((ing) => {
      const supplyId = Number(ing.supplyId);
      const supply = supplies.find(s => s.id === supplyId);
      if (supply) {
        const unitCost = parseFloat(String(supply.unitCost) || "0");
        const qty = ing.quantityWithWaste || 0;
        const cost = unitCost * qty;
        totalCost += cost;
      }
    });

    const salePrice = watchSalePrice || 0;
    const salePriceWithTax = salePrice * 1.21;
    const cmvPercentage = salePrice > 0 ? (totalCost / salePrice) * 100 : 0;
    const margin = salePrice - totalCost;
    const markup = totalCost > 0 ? ((salePrice - totalCost) / totalCost) * 100 : 0;

    return {
      totalCost,
      salePrice,
      salePriceWithTax,
      cmvPercentage,
      margin,
      markup,
    };
  }, [watchIngredients, watchSalePrice, supplies]);

  const getIngredientCost = (index: number) => {
    const ing = watchIngredients[index];
    if (!ing?.supplyId) return 0;
    
    const supplyId = Number(ing.supplyId);
    const supply = supplies.find(s => s.id === supplyId);
    if (!supply) return 0;
    
    const unitCost = parseFloat(String(supply.unitCost) || "0");
    return unitCost * (ing.quantityWithWaste || 0);
  };

  const getUsefulQuantity = (index: number) => {
    const ing = watchIngredients[index];
    if (!ing) return 0;
    
    const qty = ing.quantityWithWaste || 0;
    const waste = ing.wastePercentage || 0;
    return qty * (1 - waste / 100);
  };

  const createMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const payload = {
        ...data,
        totalCost: calculations.totalCost,
        salePriceWithTax: calculations.salePriceWithTax,
        cmvPercentage: calculations.cmvPercentage,
        margin: calculations.margin,
        markup: calculations.markup,
      };
      const res = await apiRequest("POST", "/api/recipes", payload);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recipes"] });
      toast({ title: "Receta creada correctamente" });
      navigate("/recetas");
    },
    onError: (error: Error) => {
      toast({ title: "Error al crear receta", description: error.message, variant: "destructive" });
    },
  });

  const onSubmit = (data: FormData) => {
    createMutation.mutate(data);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title={isEditing ? "Editar Receta" : "Nueva Receta"}
        description="Configure los ingredientes y costos de la receta"
        backHref="/recetas"
      />

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-3">
            <div className="lg:col-span-2 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Informacion de la Receta</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nombre del Plato *</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="Ej: Hamburguesa Completa" data-testid="input-name" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="categoryId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Categoria</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            value={field.value?.toString() || ""}
                          >
                            <FormControl>
                              <SelectTrigger data-testid="select-category">
                                <SelectValue placeholder="Seleccionar categoria" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {categories.filter(c => c.active).map((cat) => (
                                <SelectItem key={cat.id} value={cat.id.toString()}>
                                  {cat.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Descripcion</FormLabel>
                        <FormControl>
                          <Textarea {...field} placeholder="Descripcion del plato..." rows={2} data-testid="input-description" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="grid gap-4 sm:grid-cols-2">
                    <FormField
                      control={form.control}
                      name="salePrice"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Precio de Venta (sin IVA)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              step="0.01"
                              min="0"
                              {...field}
                              className="font-mono"
                              data-testid="input-sale-price"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="usefulYield"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Relleno Util Final (g/ml)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              step="0.01"
                              min="0"
                              {...field}
                              className="font-mono"
                              placeholder="Peso/volumen final servido"
                              data-testid="input-useful-yield"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between gap-2">
                  <CardTitle>Ingredientes / Insumos</CardTitle>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => appendIngredient({ supplyId: 0, quantityWithWaste: 1, wastePercentage: 0 })}
                    data-testid="button-add-ingredient"
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Agregar
                  </Button>
                </CardHeader>
                <CardContent className="space-y-4">
                  {ingredientFields.map((field, index) => {
                    const supplyId = Number(watchIngredients[index]?.supplyId) || 0;
                    const supply = supplies.find(s => s.id === supplyId);
                    
                    return (
                      <div key={field.id} className="grid gap-3 p-4 rounded-lg border bg-muted/30">
                        <div className="grid gap-3 sm:grid-cols-2">
                          <FormField
                            control={form.control}
                            name={`ingredients.${index}.supplyId`}
                            render={({ field: ingField }) => (
                              <FormItem>
                                <FormLabel>Insumo *</FormLabel>
                                <Select
                                  onValueChange={ingField.onChange}
                                  value={ingField.value?.toString() || ""}
                                >
                                  <FormControl>
                                    <SelectTrigger data-testid={`select-supply-${index}`}>
                                      <SelectValue placeholder="Seleccionar insumo" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    {supplies.filter(s => s.active).map((supply) => (
                                      <SelectItem key={supply.id} value={supply.id.toString()}>
                                        <div className="flex items-center gap-2">
                                          <Package className="h-3 w-3" />
                                          {supply.name}
                                          {supply.unitOfMeasure && (
                                            <Badge variant="outline" className="ml-1 font-mono text-xs">
                                              {formatCurrency(supply.unitCost)}/{supply.unitOfMeasure.abbreviation}
                                            </Badge>
                                          )}
                                        </div>
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <div className="flex items-end gap-2">
                            <FormField
                              control={form.control}
                              name={`ingredients.${index}.quantityWithWaste`}
                              render={({ field: ingField }) => (
                                <FormItem className="flex-1">
                                  <FormLabel>Cantidad (c/merma)</FormLabel>
                                  <FormControl>
                                    <Input
                                      type="number"
                                      step="0.0001"
                                      min="0"
                                      {...ingField}
                                      className="font-mono"
                                      data-testid={`input-quantity-${index}`}
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            {supply?.unitOfMeasure && (
                              <Badge variant="secondary" className="mb-2 font-mono">
                                {supply.unitOfMeasure.abbreviation}
                              </Badge>
                            )}
                          </div>
                        </div>
                        <div className="grid gap-3 sm:grid-cols-4">
                          <FormField
                            control={form.control}
                            name={`ingredients.${index}.wastePercentage`}
                            render={({ field: ingField }) => (
                              <FormItem>
                                <FormLabel>% Merma</FormLabel>
                                <FormControl>
                                  <Input
                                    type="number"
                                    step="0.1"
                                    min="0"
                                    max="100"
                                    {...ingField}
                                    className="font-mono"
                                    data-testid={`input-waste-${index}`}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <div>
                            <FormLabel>Cantidad Util</FormLabel>
                            <div className="h-10 px-3 py-2 rounded-md border bg-muted font-mono text-sm flex items-center">
                              {formatNumber(getUsefulQuantity(index), 4)}
                              {supply?.unitOfMeasure && (
                                <span className="text-muted-foreground ml-1">
                                  {supply.unitOfMeasure.abbreviation}
                                </span>
                              )}
                            </div>
                          </div>
                          <div>
                            <FormLabel>Costo Unitario</FormLabel>
                            <div className="h-10 px-3 py-2 rounded-md border bg-muted font-mono text-sm flex items-center">
                              {formatCurrency(supply?.unitCost || 0)}
                            </div>
                          </div>
                          <div className="flex items-end gap-2">
                            <div className="flex-1">
                              <FormLabel>Costo Total</FormLabel>
                              <div className="h-10 px-3 py-2 rounded-md border bg-primary/5 font-mono text-sm flex items-center font-medium">
                                {formatCurrency(getIngredientCost(index))}
                              </div>
                            </div>
                            {ingredientFields.length > 1 && (
                              <Button
                                type="button"
                                variant="ghost"
                                size="icon"
                                onClick={() => removeIngredient(index)}
                                data-testid={`button-remove-ingredient-${index}`}
                              >
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </CardContent>
              </Card>
            </div>

            <div>
              <Card className="sticky top-6">
                <CardHeader>
                  <CardTitle>Analisis de Rentabilidad</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center p-3 rounded-lg bg-muted/50">
                      <div className="flex items-center gap-2 text-sm">
                        <Package className="h-4 w-4 text-muted-foreground" />
                        Costo MP Total
                      </div>
                      <span className="font-mono font-medium">
                        {formatCurrency(calculations.totalCost)}
                      </span>
                    </div>

                    <div className="flex justify-between items-center p-3 rounded-lg bg-muted/50">
                      <div className="flex items-center gap-2 text-sm">
                        <DollarSign className="h-4 w-4 text-muted-foreground" />
                        Precio Venta
                      </div>
                      <span className="font-mono font-medium">
                        {formatCurrency(calculations.salePrice)}
                      </span>
                    </div>

                    <div className="flex justify-between items-center p-3 rounded-lg bg-muted/50">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <DollarSign className="h-4 w-4" />
                        Precio c/IVA (21%)
                      </div>
                      <span className="font-mono text-muted-foreground">
                        {formatCurrency(calculations.salePriceWithTax)}
                      </span>
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-3">
                    <div className="flex justify-between items-center p-3 rounded-lg border">
                      <div className="flex items-center gap-2 text-sm">
                        <Percent className="h-4 w-4 text-muted-foreground" />
                        CMV %
                      </div>
                      <Badge 
                        variant={calculations.cmvPercentage <= 30 ? "default" : calculations.cmvPercentage <= 40 ? "secondary" : "destructive"}
                        className="font-mono"
                      >
                        {formatPercentage(calculations.cmvPercentage)}
                      </Badge>
                    </div>

                    <div className="flex justify-between items-center p-3 rounded-lg border border-green-200 bg-green-50 dark:bg-green-950/20">
                      <div className="flex items-center gap-2 text-sm">
                        <TrendingUp className="h-4 w-4 text-green-600" />
                        Margen
                      </div>
                      <span className="font-mono font-medium text-green-600">
                        {formatCurrency(calculations.margin)}
                      </span>
                    </div>

                    <div className="flex justify-between items-center p-3 rounded-lg border">
                      <div className="flex items-center gap-2 text-sm">
                        <TrendingUp className="h-4 w-4 text-muted-foreground" />
                        Mark Up
                      </div>
                      <span className="font-mono font-medium">
                        {formatPercentage(calculations.markup)}
                      </span>
                    </div>
                  </div>

                  <Separator />

                  <div className="text-xs text-muted-foreground p-3 rounded-lg bg-muted/30">
                    <p className="mb-1 font-medium">Formulas utilizadas:</p>
                    <ul className="space-y-1">
                      <li>CMV% = (Costo MP / Precio Venta) x 100</li>
                      <li>Margen = Precio Venta - Costo MP</li>
                      <li>Mark Up = ((PV - Costo) / Costo) x 100</li>
                    </ul>
                  </div>

                  <div className="pt-4 space-y-2">
                    <Button
                      type="submit"
                      className="w-full"
                      disabled={createMutation.isPending}
                      data-testid="button-submit"
                    >
                      {createMutation.isPending ? "Guardando..." : "Guardar Receta"}
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      className="w-full"
                      onClick={() => navigate("/recetas")}
                      data-testid="button-cancel"
                    >
                      Cancelar
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </form>
      </Form>
    </div>
  );
}
