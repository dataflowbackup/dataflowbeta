import { useState, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { PageHeader } from "@/components/page-header";
import { DataTable, Column, FilterConfig } from "@/components/data-table";
import { ConfirmDialog } from "@/components/confirm-dialog";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatCurrency, formatDate } from "@/lib/formatters";
import { Edit, Trash2, Package, Upload, Download } from "lucide-react";
import type { Supply, Rubro, UnitOfMeasure } from "@shared/schema";

interface SupplyWithRelations extends Supply {
  rubro?: Rubro | null;
  unitOfMeasure?: UnitOfMeasure | null;
}

const formSchema = z.object({
  name: z.string().min(1, "El nombre es requerido"),
  rubroId: z.coerce.number().optional(),
  unitOfMeasureId: z.coerce.number().optional(),
});

type FormData = z.infer<typeof formSchema>;

export default function SuppliesPage() {
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isImportDialogOpen, setIsImportDialogOpen] = useState(false);
  const [editingSupply, setEditingSupply] = useState<SupplyWithRelations | null>(null);
  const [deleteSupply, setDeleteSupply] = useState<SupplyWithRelations | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { data: supplies = [], isLoading } = useQuery<SupplyWithRelations[]>({
    queryKey: ["/api/supplies"],
  });

  const { data: rubros = [] } = useQuery<Rubro[]>({
    queryKey: ["/api/rubros"],
  });

  const { data: units = [] } = useQuery<UnitOfMeasure[]>({
    queryKey: ["/api/units"],
  });

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      rubroId: undefined,
      unitOfMeasureId: undefined,
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const res = await apiRequest("POST", "/api/supplies", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/supplies"] });
      toast({ title: "Insumo creado correctamente" });
      closeDialog();
    },
    onError: (error: Error) => {
      toast({ title: "Error al crear insumo", description: error.message, variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: FormData }) => {
      const res = await apiRequest("PATCH", `/api/supplies/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/supplies"] });
      toast({ title: "Insumo actualizado correctamente" });
      closeDialog();
    },
    onError: (error: Error) => {
      toast({ title: "Error al actualizar insumo", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/supplies/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/supplies"] });
      toast({ title: "Insumo eliminado correctamente" });
      setDeleteSupply(null);
    },
    onError: (error: Error) => {
      toast({ title: "Error al eliminar insumo", description: error.message, variant: "destructive" });
    },
  });

  const importMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("file", file);
      const res = await fetch("/api/supplies/import", {
        method: "POST",
        body: formData,
        credentials: "include",
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Error al importar");
      }
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/supplies"] });
      toast({ 
        title: "Importacion completada", 
        description: `${data.imported} de ${data.total} insumos importados` 
      });
      setIsImportDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({ title: "Error al importar", description: error.message, variant: "destructive" });
    },
  });

  const handleExport = async () => {
    try {
      const res = await fetch("/api/supplies/export", {
        method: "GET",
        credentials: "include",
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Error al exportar");
      }
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "insumos.xlsx";
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error: any) {
      toast({ title: "Error al exportar", description: error.message, variant: "destructive" });
    }
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      importMutation.mutate(file);
    }
  };

  const openCreate = () => {
    setEditingSupply(null);
    form.reset({ name: "", rubroId: undefined, unitOfMeasureId: undefined });
    setIsDialogOpen(true);
  };

  const openEdit = (supply: SupplyWithRelations) => {
    setEditingSupply(supply);
    form.reset({
      name: supply.name,
      rubroId: supply.rubroId || undefined,
      unitOfMeasureId: supply.unitOfMeasureId || undefined,
    });
    setIsDialogOpen(true);
  };

  const closeDialog = () => {
    setIsDialogOpen(false);
    setEditingSupply(null);
    form.reset();
  };

  const onSubmit = (data: FormData) => {
    if (editingSupply) {
      updateMutation.mutate({ id: editingSupply.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const columns: Column<SupplyWithRelations>[] = [
    {
      key: "name",
      header: "Nombre",
      cell: (row) => (
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
            <Package className="h-4 w-4 text-primary" />
          </div>
          <span className="font-medium">{row.name}</span>
        </div>
      ),
    },
    {
      key: "rubro",
      header: "Rubro",
      cell: (row) =>
        row.rubro ? (
          <Badge variant="secondary">{row.rubro.name}</Badge>
        ) : (
          <span className="text-muted-foreground">-</span>
        ),
    },
    {
      key: "unit",
      header: "Unidad",
      cell: (row) =>
        row.unitOfMeasure ? (
          <Badge variant="outline" className="font-mono">
            {row.unitOfMeasure.abbreviation}
          </Badge>
        ) : (
          <span className="text-muted-foreground">-</span>
        ),
    },
    {
      key: "unitCost",
      header: "Costo Unitario",
      cell: (row) => (
        <span className="font-mono text-sm">
          {formatCurrency(row.unitCost)}
          {row.unitOfMeasure && (
            <span className="text-muted-foreground">/{row.unitOfMeasure.abbreviation}</span>
          )}
        </span>
      ),
    },
    {
      key: "lastCost",
      header: "Ultima Compra",
      cell: (row) => (
        <div className="text-sm">
          <div className="font-mono">{formatCurrency(row.lastCost)}</div>
          {row.lastQuantity && parseFloat(String(row.lastQuantity)) > 0 && (
            <div className="text-xs text-muted-foreground">
              x{parseFloat(String(row.lastQuantity))} {row.unitOfMeasure?.abbreviation || "u"}
            </div>
          )}
          {row.lastPurchaseDate && (
            <div className="text-xs text-muted-foreground">
              {formatDate(row.lastPurchaseDate)}
            </div>
          )}
        </div>
      ),
    },
    {
      key: "active",
      header: "Estado",
      cell: (row) => (
        <Badge variant={row.active ? "default" : "secondary"}>
          {row.active ? "Activo" : "Inactivo"}
        </Badge>
      ),
    },
    {
      key: "actions",
      header: "",
      className: "w-24",
      cell: (row) => (
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => openEdit(row)}
            data-testid={`button-edit-${row.id}`}
          >
            <Edit className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setDeleteSupply(row)}
            data-testid={`button-delete-${row.id}`}
          >
            <Trash2 className="h-4 w-4 text-destructive" />
          </Button>
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Insumos"
        description="Gestiona los insumos y materias primas"
        actions={
          <div className="flex gap-2">
            <Button variant="outline" onClick={handleExport} data-testid="button-export">
              <Download className="h-4 w-4 mr-2" />
              Exportar
            </Button>
            <Button variant="outline" onClick={() => setIsImportDialogOpen(true)} data-testid="button-import">
              <Upload className="h-4 w-4 mr-2" />
              Importar
            </Button>
          </div>
        }
      />

      <DataTable
        columns={columns}
        data={supplies}
        isLoading={isLoading}
        searchPlaceholder="Buscar por nombre..."
        searchKeys={["name"]}
        filters={[
          {
            key: "rubroId",
            label: "Rubro",
            allLabel: "Todos los rubros",
            options: rubros.map((r) => ({ value: String(r.id), label: r.name })),
          },
          {
            key: "active",
            label: "Estado",
            allLabel: "Todos los estados",
            options: [
              { value: "true", label: "Activo" },
              { value: "false", label: "Inactivo" },
            ],
          },
        ] as FilterConfig<SupplyWithRelations>[]}
        onAdd={openCreate}
        addLabel="Nuevo Insumo"
        emptyMessage="No hay insumos registrados. Los costos se actualizan automaticamente al cargar facturas."
      />

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editingSupply ? "Editar Insumo" : "Nuevo Insumo"}
            </DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nombre *</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Nombre del insumo" data-testid="input-name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="rubroId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Rubro</FormLabel>
                      <Select
                        onValueChange={(val) => field.onChange(val ? parseInt(val) : undefined)}
                        value={field.value?.toString() || ""}
                      >
                        <FormControl>
                          <SelectTrigger data-testid="select-rubro">
                            <SelectValue placeholder="Seleccionar rubro" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {rubros.filter(r => r.active).map((rubro) => (
                            <SelectItem key={rubro.id} value={rubro.id.toString()}>
                              {rubro.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="unitOfMeasureId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Unidad de Medida</FormLabel>
                      <Select
                        onValueChange={(val) => field.onChange(val ? parseInt(val) : undefined)}
                        value={field.value?.toString() || ""}
                      >
                        <FormControl>
                          <SelectTrigger data-testid="select-unit">
                            <SelectValue placeholder="Seleccionar unidad" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {units.filter(u => u.active).map((unit) => (
                            <SelectItem key={unit.id} value={unit.id.toString()}>
                              {unit.name} ({unit.abbreviation})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="flex justify-end gap-2 pt-4">
                <Button type="button" variant="outline" onClick={closeDialog} data-testid="button-cancel">
                  Cancelar
                </Button>
                <Button
                  type="submit"
                  disabled={createMutation.isPending || updateMutation.isPending}
                  data-testid="button-submit"
                >
                  {createMutation.isPending || updateMutation.isPending
                    ? "Guardando..."
                    : editingSupply
                    ? "Actualizar"
                    : "Crear"}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={!!deleteSupply}
        onOpenChange={(open) => !open && setDeleteSupply(null)}
        title="Eliminar Insumo"
        description={`¿Esta seguro que desea eliminar el insumo "${deleteSupply?.name}"? Esta accion no se puede deshacer.`}
        confirmLabel="Eliminar"
        onConfirm={() => deleteSupply && deleteMutation.mutate(deleteSupply.id)}
        variant="destructive"
        isLoading={deleteMutation.isPending}
      />

      <Dialog open={isImportDialogOpen} onOpenChange={setIsImportDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Importar Insumos</DialogTitle>
            <DialogDescription>
              Sube un archivo Excel con los insumos a importar. El archivo debe tener las columnas: Nombre (requerido), Codigo, Rubro, Unidad, Costo Unitario, Stock Minimo, Stock Actual.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <Input
              ref={fileInputRef}
              type="file"
              accept=".xlsx,.xls"
              onChange={handleImportFile}
              data-testid="input-import-file"
            />
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsImportDialogOpen(false)}>
                Cancelar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
